import assert from 'node:assert/strict';
import {
  USB_MESSAGE_TYPES,
  PROTOCOL_VERSION,
  PACKET_NUMBER_OFFSET,
  CRC_DATA_OFFSET,
  CRC_SIZE,
  getSchemaById,
  encodePayload,
  buildPacket,
  crc16CcittFalse,
} from '../src/protocol.js';
import { PacketStreamParser } from '../src/serial-link.js';

assert.equal(crc16CcittFalse(new TextEncoder().encode('123456789')), 0x29b1);

const commandSchema = getSchemaById(USB_MESSAGE_TYPES.COMMAND);
const payload = encodePayload(commandSchema, {
  flags: { targSlot: true, activeSlot: false },
  gimbalX: -1234,
  gimbalY: 2345,
  motor0Speed: 67,
  motor1Speed: 89,
  empty0: 0,
});

const frame = buildPacket(0x1234, USB_MESSAGE_TYPES.COMMAND, payload);
assert.deepEqual(Array.from(frame.slice(0, 3)), [0xa5, 0x5a, PROTOCOL_VERSION]);
assert.equal(new DataView(frame.buffer).getUint16(PACKET_NUMBER_OFFSET, true), 0x1234);
assert.equal(frame[5], USB_MESSAGE_TYPES.COMMAND);
assert.equal(frame[6], payload.length);
assert.equal(frame.length, 7 + payload.length + CRC_SIZE);

// Firmware calls usb_packet_crc(tx_packet), so CRC coverage starts at the
// packed usb_header_t (packet number) and excludes sync and version bytes.
const crcOffset = frame.length - CRC_SIZE;
const transmittedCrc = new DataView(frame.buffer).getUint16(crcOffset, true);
assert.equal(CRC_DATA_OFFSET, 3);
assert.equal(transmittedCrc, 0x4b4f);
assert.equal(transmittedCrc, crc16CcittFalse(frame.subarray(CRC_DATA_OFFSET, crcOffset)));
assert.notEqual(transmittedCrc, crc16CcittFalse(frame.subarray(2, crcOffset)));

const fragmentedParser = new PacketStreamParser();
const fragmentedPackets = [
  ...fragmentedParser.push(frame.slice(0, 4)),
  ...fragmentedParser.push(frame.slice(4, 10)),
  ...fragmentedParser.push(frame.slice(10)),
];
assert.equal(fragmentedPackets.length, 1);
assert.equal(fragmentedPackets[0].packetNumber, 0x1234);
assert.equal(fragmentedPackets[0].crcValid, true);
assert.deepEqual(Array.from(fragmentedPackets[0].payload), Array.from(payload));

const corrupted = frame.slice();
corrupted[7] ^= 0x01;
const nextFrame = buildPacket(0x1235, USB_MESSAGE_TYPES.COMMAND, payload);
const noisyStream = new Uint8Array(3 + corrupted.length + nextFrame.length);
noisyStream.set([0x00, 0xff, 0xa5], 0);
noisyStream.set(corrupted, 3);
noisyStream.set(nextFrame, 3 + corrupted.length);

const recoveryParser = new PacketStreamParser();
const recovered = recoveryParser.push(noisyStream);
assert.equal(recovered.length, 1);
assert.equal(recovered[0].packetNumber, 0x1235);
assert.ok(recoveryParser.crcErrors >= 1);
assert.ok(recoveryParser.badFrames >= 1);

console.log('Protocol framing tests passed');
