# AERE Drone Serial Dashboard

A web dashboard for the AFC drone USB serial protocol. The Python server owns the physical serial port, while browser clients receive telemetry and send commands through a WebSocket connection to that server.

This allows the dashboard to be opened from another computer without giving that client direct access to the drone's USB device. The drone must be connected to the computer running `server.py`.

## Architecture

```text
Drone USB serial
       |
       v
Python dashboard server
  - opens COM or /dev/tty port
  - serves the dashboard
  - bridges serial bytes over WebSocket
       |
       v
One or more browser clients
```

The server maintains one serial connection. All open dashboard clients can view the same incoming telemetry. Because command packets are also forwarded, access to the dashboard should be limited to trusted users and networks.

## Features

- Server-side serial port selection and connection
- Remote browser access without Web Serial support
- Live decoding of the telemetry payload defined in `PACKET_SCHEMAS`
- Client-side satellite map following telemetry latitude and longitude at zoom 22
- Current telemetry cards plus short loop-time and RSSI histories
- Command controls for target slot, active slot, gimbal values, and both motors
- Motor output interlock and a stop-motors action
- Optional continuous command transmission from 1 to 50 Hz
- Debug-text terminal
- Framed RX/TX packet monitor with CRC validation, decoded fields, and hexadecimal inspection
- Generic outbound packet builder generated from packet schemas
- Raw packet builder for testing new packet types
- Packet log export to JSON
- Demo mode for testing the UI without hardware

## Requirements

- Python 3.10 or newer
- A serial device connected to the server computer
- Network access from the browser to the server's HTTP port
- Internet access from each browser client for Leaflet and satellite imagery tiles

The included start scripts create a local `.venv` and install:

- `aiohttp`
- `pyserial`

## Start the server

### Windows

Double-click `start-dashboard.bat`, or run:

```powershell
start-dashboard.bat
```

Then open:

```text
http://localhost:8000
```

### Linux or macOS

```bash
chmod +x start-dashboard.sh
./start-dashboard.sh
```

Then open:

```text
http://localhost:8000
```

The server listens on all interfaces by default. From another computer, use the server computer's hostname or IP address:

```text
http://SERVER_ADDRESS:8000
```

## Satellite position map

The **Flight position** panel reads the `latitude` and `longitude` fields from each telemetry packet. After the first non-zero, valid coordinate arrives, the map:

- places a marker at the latest position
- maintains a short flight trail
- centers the marker at zoom level 22 while **Follow drone** is enabled
- allows manual panning and zooming when follow mode is disabled
- returns to the latest coordinate with **Recenter**

Leaflet and Esri World Imagery are loaded directly by the browser; map traffic does not pass through `server.py`. The page therefore needs client-side internet access even when the serial bridge is running entirely on a local network.

The imagery layer uses native tiles through zoom 19 and digitally enlarges them through zoom 22. Actual ground resolution depends on imagery coverage at the reported coordinates. A coordinate of `0, 0` is treated as no GPS fix because the current firmware initializes unavailable telemetry fields to zero.

## Connect to the drone

1. Connect the drone controller over USB to the server computer.
2. Start the dashboard server.
3. Open the dashboard in a browser.
4. Select the serial device listed under **Server port**.
5. Select the baud rate.
6. Select **Connect Serial**.
7. Open the **Packets** tab to verify frames are arriving.

Use **Refresh Ports** after plugging in or removing a serial device.

## Start with a serial port already connected

The server can open a port during startup:

### Linux

```bash
./start-dashboard.sh --serial-port /dev/ttyACM0 --baud 115200
```

### Windows

```powershell
start-dashboard.bat --serial-port COM3 --baud 115200
```

Other server options:

```text
--host ADDRESS       HTTP bind address; default 0.0.0.0
--http-port PORT     Dashboard HTTP port; default 8000
--serial-port PORT   Port to open at startup
--baud RATE          Startup baud rate; default 115200
--verbose            Enable debug logging
```

## Linux serial permissions

The account running the server must have access to the serial device. On many distributions, add the account to the `dialout` group:

```bash
sudo usermod -aG dialout "$USER"
```

Log out and back in before trying again. The exact group may differ by distribution.

## Current protocol

Each serial packet is encoded as:

```text
A5 5A | version | packetNum LE16 | type | length | payload | CRC-16 LE16
```

| Offset | Size | Field |
|---:|---:|---|
| 0 | 2 | Sync word: `A5 5A` |
| 2 | 1 | Protocol version; currently `01` |
| 3 | 2 | Packet number, unsigned little-endian |
| 5 | 1 | Message type |
| 6 | 1 | Payload length |
| 7 | 0-60 | Payload |
| 7 + length | 2 | CRC-16, unsigned little-endian |

Current message type values:

| Type | Name |
|---:|---|
| 0 | RAW |
| 1 | DEBUG_TEXT |
| 2 | RADIO_PACKET |
| 3 | TELEMETRY |
| 4 | COMMAND |

All multibyte packet fields and payload values are decoded little-endian to match the packed structures sent by the microcontroller.

### CRC configuration

The dashboard currently uses **CRC-16/CCITT-FALSE** with:

- polynomial `0x1021`
- initial value `0xFFFF`
- no input or output reflection
- final XOR `0x0000`
- CRC calculated over the packed `usb_header_t` and the used payload bytes
- Sync bytes and the protocol-version byte are not included in the CRC

The CRC is transmitted little-endian. This matches the firmware transmit path, which calls `usb_packet_crc(tx_packet)` before serializing the CRC. If the firmware uses a different CRC-16 variant, update `CRC16_CONFIG` and `crc16CcittFalse()` in `src/protocol.js`.

### Parser behavior

The browser parser searches the serial stream for `A5 5A`, then validates the version, payload length, and CRC before emitting a packet. Invalid frames are discarded and the parser resumes scanning for the next sync word. This allows recovery after dropped, inserted, or corrupted serial bytes.

## Add a packet structure

Packet layouts are defined in `src/protocol.js` inside `PACKET_SCHEMAS`. Adding a fixed-length packet usually requires only one schema object:

```js
{
  id: 5,
  name: 'Configuration',
  direction: 'out',
  fields: [
    { key: 'enabled', label: 'Enabled', type: 'uint8', default: 0 },
    { key: 'gain', label: 'Gain', type: 'float32', default: 1.0 },
    { key: 'limit', label: 'Limit', type: 'int16', default: 0 },
  ],
}
```

The generic packet builder automatically creates inputs for outbound schemas. Incoming packets are decoded and shown in the packet monitor.

Supported field types:

- `uint8`, `int8`
- `uint16`, `int16`
- `uint32`, `int32`
- `float32`, `float64`
- `bitfield8`
- fixed-length `bytes`
- fixed-length `string`

For variable-length or unusual layouts, add a custom `decoder(payload)` or `encoder(values)` function to the schema.

## Files

- `server.py` - HTTP server, WebSocket endpoint, and server-side serial connection
- `requirements.txt` - Python runtime dependencies
- `index.html` - dashboard structure
- `styles.css` - responsive dashboard styling
- `src/protocol.js` - packet IDs, schemas, encoder, decoder, and frame builder
- `src/serial-link.js` - WebSocket client and streaming packet parser
- `src/app.js` - UI state and event handling

## Protocol tests

With Node.js installed, run the framing, CRC, fragmentation, and resynchronization tests with:

```bash
node --experimental-default-type=module tests/protocol.test.mjs
```
