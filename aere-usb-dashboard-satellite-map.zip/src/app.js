import {
  USB_MESSAGE_TYPES,
  PACKET_SCHEMAS,
  getSchemaById,
  getOutboundSchemas,
  decodePayload,
  encodePayload,
  buildPacket,
  bytesToHex,
  hexToBytes,
  formatFieldValue,
} from './protocol.js';
import { SerialLink } from './serial-link.js';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

const link = new SerialLink();
const state = {
  connected: false,
  bridgeConnected: false,
  currentPort: null,
  demoRunning: false,
  demoTimer: null,
  liveTimer: null,
  rxPackets: 0,
  txPackets: 0,
  badFrames: 0,
  packetTimes: [],
  lastTelemetryAt: null,
  lastTelemetry: null,
  packetRows: [],
  history: {
    loopTimeAvg: [],
    loopTimeMax: [],
    rssi: [],
  },
};

const telemetrySchema = getSchemaById(USB_MESSAGE_TYPES.TELEMETRY);
const commandSchema = getSchemaById(USB_MESSAGE_TYPES.COMMAND);

const MAP_ZOOM = 22;
const MAP_DEFAULT_CENTER = [47.1164, -88.5385];
const MAP_MAX_TRAIL_POINTS = 600;
let telemetryMap = null;
let mapTileLayer = null;
let mapPositionMarker = null;
let mapTrailLayer = null;
let mapTrailCoordinates = [];
let lastMapPosition = null;
let mapTileError = false;

function setText(id, value) {
  const element = document.getElementById(id);
  if (element) element.textContent = value;
}

function showToast(message, tone = 'info') {
  const region = $('#toast-region');
  const toast = document.createElement('div');
  toast.className = `toast toast-${tone}`;
  toast.textContent = message;
  region.append(toast);
  requestAnimationFrame(() => toast.classList.add('visible'));
  window.setTimeout(() => {
    toast.classList.remove('visible');
    window.setTimeout(() => toast.remove(), 180);
  }, 3500);
}

function setConnectionStatus(connected, label = null) {
  state.connected = connected;

  let displayLabel = label;
  if (!displayLabel) {
    if (state.demoRunning) displayLabel = 'Demo';
    else if (!state.bridgeConnected) displayLabel = 'Server Offline';
    else displayLabel = connected ? 'Connected' : 'Serial Disconnected';
  }

  const badge = $('#connection-badge');
  badge.innerHTML = `<span id="connection-dot" class="status-dot ${connected ? 'online' : ''}"></span>${escapeHtml(displayLabel)}`;
  badge.classList.toggle('connected', connected);

  const connectButton = $('#connect-button');
  connectButton.textContent = connected ? 'Disconnect' : 'Connect Serial';
  connectButton.disabled = !state.bridgeConnected || (!connected && !$('#serial-port').value);
  $('#refresh-ports').disabled = !state.bridgeConnected;

  setText('metric-connection', displayLabel);
  if (state.demoRunning) {
    setText('metric-connection-detail', 'Simulated source');
  } else if (!state.bridgeConnected) {
    setText('metric-connection-detail', 'No server bridge');
  } else if (connected) {
    setText('metric-connection-detail', `${state.currentPort || 'Server serial'} active`);
  } else {
    setText('metric-connection-detail', 'Server ready; no serial port open');
  }
}

function setBridgeStatus(connected) {
  state.bridgeConnected = connected;
  $('#server-warning').hidden = connected;
  if (!connected) {
    state.currentPort = null;
    setConnectionStatus(false, 'Server Offline');
  } else {
    setConnectionStatus(state.connected);
  }
}

function renderSerialPorts(ports) {
  const select = $('#serial-port');
  const previous = state.currentPort || select.value;
  select.innerHTML = '';

  if (!ports.length) {
    const option = document.createElement('option');
    option.value = '';
    option.textContent = 'No serial ports found';
    select.append(option);
  } else {
    for (const port of ports) {
      const option = document.createElement('option');
      option.value = port.device;
      const description = port.description && port.description !== port.device ? ` - ${port.description}` : '';
      option.textContent = `${port.device}${description}`;
      select.append(option);
    }
    if (ports.some((port) => port.device === previous)) select.value = previous;
  }

  setConnectionStatus(state.connected);
}

function formatRuntime(seconds) {
  const value = Number(seconds) || 0;
  const h = Math.floor(value / 3600);
  const m = Math.floor((value % 3600) / 60);
  const s = Math.floor(value % 60);
  return [h, m, s].map((part) => String(part).padStart(2, '0')).join(':');
}

function formatAge(timestamp) {
  if (!timestamp) return 'Never';
  const seconds = Math.max(0, (performance.now() - timestamp) / 1000);
  if (seconds < 1) return `${Math.round(seconds * 1000)} ms ago`;
  if (seconds < 60) return `${seconds.toFixed(1)} s ago`;
  return `${Math.floor(seconds / 60)} min ago`;
}

function addHistory(key, value, limit = 120) {
  const series = state.history[key];
  series.push(Number(value) || 0);
  if (series.length > limit) series.splice(0, series.length - limit);
}

function drawSparkline(canvas, seriesList) {
  if (!canvas) return;
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.max(1, Math.floor(rect.width * dpr));
  canvas.height = Math.max(1, Math.floor(rect.height * dpr));
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, rect.width, rect.height);

  const allValues = seriesList.flatMap((item) => item.values).filter(Number.isFinite);
  if (allValues.length < 2) {
    ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--muted');
    ctx.font = '12px system-ui';
    ctx.fillText('Waiting for telemetry', 8, 22);
    return;
  }

  let min = Math.min(...allValues);
  let max = Math.max(...allValues);
  if (max === min) {
    max += 1;
    min -= 1;
  }
  const pad = 8;
  const width = rect.width - pad * 2;
  const height = rect.height - pad * 2;
  const styles = getComputedStyle(document.documentElement);

  ctx.strokeStyle = styles.getPropertyValue('--border');
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(pad, rect.height - pad);
  ctx.lineTo(rect.width - pad, rect.height - pad);
  ctx.stroke();

  seriesList.forEach((series, seriesIndex) => {
    const values = series.values;
    if (values.length < 2) return;
    ctx.strokeStyle = series.color || styles.getPropertyValue(seriesIndex === 0 ? '--accent' : '--warning');
    ctx.lineWidth = 2;
    ctx.beginPath();
    values.forEach((value, index) => {
      const x = pad + (index / Math.max(1, values.length - 1)) * width;
      const y = pad + (1 - (value - min) / (max - min)) * height;
      if (index === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
  });
}

function renderCharts() {
  drawSparkline($('#loop-chart'), [
    { values: state.history.loopTimeAvg },
    { values: state.history.loopTimeMax },
  ]);
  drawSparkline($('#rssi-chart'), [{ values: state.history.rssi }]);
}

function setMapStatus(message, tone = '') {
  const status = $('#map-status');
  if (!status) return;
  status.textContent = message;
  status.classList.toggle('has-fix', tone === 'success');
  status.classList.toggle('error', tone === 'error');
}

function isValidTelemetryPosition(latitude, longitude) {
  return (
    Number.isFinite(latitude) &&
    Number.isFinite(longitude) &&
    latitude >= -90 &&
    latitude <= 90 &&
    longitude >= -180 &&
    longitude <= 180 &&
    !(latitude === 0 && longitude === 0)
  );
}

function initializeMap() {
  const container = $('#telemetry-map');
  if (!container) return;

  if (!window.L) {
    setMapStatus('Map library failed to load. Check this client\'s internet connection.', 'error');
    return;
  }

  telemetryMap = window.L.map(container, {
    center: MAP_DEFAULT_CENTER,
    zoom: MAP_ZOOM,
    minZoom: 1,
    maxZoom: MAP_ZOOM,
    zoomControl: true,
    preferCanvas: true,
  });

  mapTileLayer = window.L.tileLayer(
    'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    {
      attribution: '&copy; Esri, Maxar, Earthstar Geographics, and the GIS User Community',
      maxZoom: MAP_ZOOM,
      maxNativeZoom: 19,
    },
  ).addTo(telemetryMap);

  const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#42b8ff';
  mapTrailLayer = window.L.polyline([], {
    color: accent,
    weight: 3,
    opacity: 0.85,
    interactive: false,
  }).addTo(telemetryMap);

  mapTileLayer.on('tileerror', () => {
    if (mapTileError) return;
    mapTileError = true;
    setMapStatus('Satellite imagery could not be loaded by this browser.', 'error');
  });

  telemetryMap.on('zoomend', () => setText('map-zoom', telemetryMap.getZoom()));
  setText('map-zoom', telemetryMap.getZoom());
  requestAnimationFrame(() => telemetryMap.invalidateSize({ pan: false }));
}

function updateTelemetryMap(decoded) {
  const latitude = Number(decoded.latitude);
  const longitude = Number(decoded.longitude);

  setText('map-latitude', Number.isFinite(latitude) ? latitude.toFixed(7) : '--');
  setText('map-longitude', Number.isFinite(longitude) ? longitude.toFixed(7) : '--');

  if (!isValidTelemetryPosition(latitude, longitude)) {
    setMapStatus('Waiting for a non-zero GPS position');
    return;
  }

  if (!telemetryMap) initializeMap();
  if (!telemetryMap) return;

  const position = window.L.latLng(latitude, longitude);
  const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#42b8ff';

  if (!mapPositionMarker) {
    mapPositionMarker = window.L.circleMarker(position, {
      radius: 8,
      color: '#ffffff',
      weight: 3,
      fillColor: accent,
      fillOpacity: 0.9,
      className: 'drone-position-marker',
    }).addTo(telemetryMap);
  } else {
    mapPositionMarker.setLatLng(position);
  }

  mapPositionMarker.bindTooltip(
    `Drone<br>${latitude.toFixed(7)}, ${longitude.toFixed(7)}`,
    { direction: 'top', offset: [0, -8] },
  );

  if (!lastMapPosition || telemetryMap.distance(lastMapPosition, position) >= 0.25) {
    mapTrailCoordinates.push(position);
    if (mapTrailCoordinates.length > MAP_MAX_TRAIL_POINTS) {
      mapTrailCoordinates.splice(0, mapTrailCoordinates.length - MAP_MAX_TRAIL_POINTS);
    }
    mapTrailLayer.setLatLngs(mapTrailCoordinates);
  }

  const firstFix = lastMapPosition === null;
  lastMapPosition = position;
  $('#map-recenter').disabled = false;

  if (firstFix || $('#map-follow').checked) {
    telemetryMap.setView(position, MAP_ZOOM, { animate: false });
  }

  setText('map-zoom', telemetryMap.getZoom());
  setMapStatus(
    mapTileError ? 'GPS position received; satellite imagery is unavailable.' : 'Tracking latest GPS position',
    mapTileError ? 'error' : 'success',
  );
}

function updateTelemetry(decoded) {
  state.lastTelemetry = decoded;
  state.lastTelemetryAt = performance.now();

  setText('metric-loop-avg', `${decoded.loopTimeAvg ?? '--'} us`);
  setText('metric-loop-max', `Max ${decoded.loopTimeMax ?? '--'} us`);
  setText('metric-rssi', decoded.rssi ?? '--');
  setText('metric-mode', decoded.currentMode ?? '--');
  setText('metric-runtime', formatRuntime(decoded.runTime));
  setText('metric-voltage', decoded.voltage ?? '--');
  setText('metric-motors', `${decoded.motor1Set ?? '--'} / ${decoded.motor2Set ?? '--'}`);
  setText('metric-gimbal', `${decoded.gimbalPitch ?? '--'} / ${decoded.gimbalYaw ?? '--'}`);
  updateTelemetryMap(decoded);

  const telemetryTable = $('#telemetry-table-body');
  telemetryTable.innerHTML = '';
  for (const field of telemetrySchema.fields) {
    const row = document.createElement('tr');
    row.dataset.group = field.group;
    row.innerHTML = `
      <td>${escapeHtml(field.group)}</td>
      <td>${escapeHtml(field.label)}</td>
      <td class="value-cell">${escapeHtml(formatFieldValue(field, decoded[field.key]))}</td>
      <td>${escapeHtml(field.unit || '')}</td>
    `;
    telemetryTable.append(row);
  }

  addHistory('loopTimeAvg', decoded.loopTimeAvg);
  addHistory('loopTimeMax', decoded.loopTimeMax);
  addHistory('rssi', decoded.rssi);
  renderCharts();
}

function updatePacketRate() {
  const now = performance.now();
  state.packetTimes = state.packetTimes.filter((time) => now - time <= 1000);
  setText('metric-packet-rate', `${state.packetTimes.length} pkt/s`);
  setText('metric-rx', state.rxPackets);
  setText('metric-tx', state.txPackets);
  setText('metric-errors', state.badFrames);
  setText('last-telemetry-age', formatAge(state.lastTelemetryAt));
}

function resolvePacketSchema(packet) {
  let effectiveType = packet.type;
  let compatibilityNote = '';
  const compatibilityEnabled = $('#compat-telemetry').checked;

  // usb_send() in the supplied firmware currently writes DEBUG_TEXT for every
  // outbound packet. The telemetry payload is exactly 54 bytes, so this allows
  // the dashboard to remain usable until that firmware line is corrected.
  if (
    compatibilityEnabled &&
    packet.type === USB_MESSAGE_TYPES.DEBUG_TEXT &&
    packet.payloadLength === 54
  ) {
    effectiveType = USB_MESSAGE_TYPES.TELEMETRY;
    compatibilityNote = 'Firmware type workaround';
  }

  return { effectiveType, schema: getSchemaById(effectiveType), compatibilityNote };
}

function handlePacket(packet) {
  state.rxPackets += 1;
  state.packetTimes.push(performance.now());

  const { effectiveType, schema, compatibilityNote } = resolvePacketSchema(packet);
  let decoded = null;
  let decodeError = '';

  try {
    decoded = decodePayload(schema, packet.payload);
  } catch (error) {
    decodeError = error.message;
    state.badFrames += 1;
  }

  if (!decodeError && effectiveType === USB_MESSAGE_TYPES.TELEMETRY) updateTelemetry(decoded);
  if (!decodeError && effectiveType === USB_MESSAGE_TYPES.DEBUG_TEXT) appendTerminal(decoded.text, 'rx');

  addPacketRow({
    direction: 'RX',
    packetNumber: packet.packetNumber,
    type: packet.type,
    effectiveType,
    typeName: schema?.name ?? `Unknown (${packet.type})`,
    length: packet.payloadLength,
    payload: packet.payload,
    decoded,
    note: decodeError || compatibilityNote,
    timestamp: new Date(),
  });
  updatePacketRate();
}

function summarizeDecoded(decoded) {
  if (!decoded) return '';
  if (typeof decoded.text === 'string') return decoded.text.replace(/\s+/g, ' ').slice(0, 80);
  return Object.entries(decoded)
    .slice(0, 4)
    .map(([key, value]) => `${key}=${typeof value === 'object' ? JSON.stringify(value) : value}`)
    .join(', ');
}

function addPacketRow(packet) {
  state.packetRows.unshift(packet);
  if (state.packetRows.length > 250) state.packetRows.length = 250;
  renderPacketRows();
}

function renderPacketRows() {
  const tbody = $('#packet-table-body');
  const filter = $('#packet-filter').value;
  tbody.innerHTML = '';

  const rows = state.packetRows.filter((row) => filter === 'all' || row.direction.toLowerCase() === filter);
  for (const row of rows.slice(0, 100)) {
    const tr = document.createElement('tr');
    const typeLabel = row.type === row.effectiveType ? `${row.typeName} (${row.type})` : `${row.typeName} (${row.type}->${row.effectiveType})`;
    tr.innerHTML = `
      <td>${row.timestamp.toLocaleTimeString()}</td>
      <td><span class="direction-pill ${row.direction.toLowerCase()}">${row.direction}</span></td>
      <td>${row.packetNumber}</td>
      <td>${escapeHtml(typeLabel)}</td>
      <td>${row.length}</td>
      <td class="packet-summary">${escapeHtml(row.note || summarizeDecoded(row.decoded) || bytesToHex(row.payload).slice(0, 80))}</td>
      <td><button class="secondary small inspect-packet" type="button">Inspect</button></td>
    `;
    $('.inspect-packet', tr).addEventListener('click', () => inspectPacket(row));
    tbody.append(tr);
  }
}

function inspectPacket(row) {
  $('#packet-dialog-title').textContent = `${row.direction} ${row.typeName} packet #${row.packetNumber}`;
  $('#packet-dialog-meta').textContent = `${row.length} payload bytes | Type ${row.type}`;
  $('#packet-dialog-hex').textContent = bytesToHex(row.payload) || '(empty payload)';
  $('#packet-dialog-decoded').textContent = row.decoded ? JSON.stringify(row.decoded, null, 2) : row.note || 'No schema available';
  $('#packet-dialog').showModal();
}

function appendTerminal(text, direction = 'system') {
  const terminal = $('#terminal-output');
  const line = document.createElement('div');
  line.className = `terminal-line ${direction}`;
  const prefix = direction === 'rx' ? 'RX' : direction === 'tx' ? 'TX' : '--';
  line.innerHTML = `<span class="terminal-time">${new Date().toLocaleTimeString()}</span><span class="terminal-direction">${prefix}</span><span>${escapeHtml(String(text))}</span>`;
  terminal.append(line);
  while (terminal.children.length > 500) terminal.firstElementChild.remove();
  terminal.scrollTop = terminal.scrollHeight;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

async function sendFrame(type, payload, decoded = null, label = null) {
  let frame;
  let packetNumber;

  if (state.demoRunning && !state.connected) {
    packetNumber = state.txPackets & 0xffff;
    frame = buildPacket(packetNumber, type, payload);
  } else {
    frame = await link.send(type, payload);
    packetNumber = new DataView(frame.buffer).getUint16(0, true);
  }

  state.txPackets += 1;
  addPacketRow({
    direction: 'TX',
    packetNumber,
    type,
    effectiveType: type,
    typeName: label || getSchemaById(type)?.name || `Unknown (${type})`,
    length: payload.length,
    payload,
    decoded,
    note: state.demoRunning && !state.connected ? 'Demo mode - not transmitted' : '',
    timestamp: new Date(),
  });
  updatePacketRate();
  return frame;
}

function commandValuesFromForm(forceMotorsOff = false) {
  const motorsEnabled = $('#motor-enable').checked && !forceMotorsOff;
  return {
    flags: {
      targSlot: Number($('input[name="target-slot"]:checked').value) === 1,
      activeSlot: Number($('input[name="active-slot"]:checked').value) === 1,
    },
    gimbalX: Number($('#gimbal-x').value),
    gimbalY: Number($('#gimbal-y').value),
    motor0Speed: motorsEnabled ? Number($('#motor-0').value) : 0,
    motor1Speed: motorsEnabled ? Number($('#motor-1').value) : 0,
    empty0: 0,
  };
}

async function sendCommand(forceMotorsOff = false) {
  try {
    if (!state.connected && !state.demoRunning) throw new Error('Connect the server serial port or start demo mode first');
    const values = commandValuesFromForm(forceMotorsOff);
    const payload = encodePayload(commandSchema, values);
    await sendFrame(commandSchema.id, payload, values);
    setText('last-command-status', `Sent at ${new Date().toLocaleTimeString()}`);
  } catch (error) {
    showToast(error.message, 'error');
    setText('last-command-status', error.message);
  }
}

function syncRangePair(rangeId, numberId) {
  const range = document.getElementById(rangeId);
  const number = document.getElementById(numberId);
  range.addEventListener('input', () => { number.value = range.value; });
  number.addEventListener('input', () => { range.value = number.value; });
}

function updateLiveSend() {
  window.clearInterval(state.liveTimer);
  state.liveTimer = null;
  const enabled = $('#live-send').checked;
  const rate = Math.max(1, Math.min(50, Number($('#live-rate').value) || 10));
  if (enabled) state.liveTimer = window.setInterval(() => sendCommand(false), 1000 / rate);
}

async function emergencyStop() {
  $('#live-send').checked = false;
  $('#motor-enable').checked = false;
  $('#motor-0').value = '0';
  $('#motor-0-number').value = '0';
  $('#motor-1').value = '0';
  $('#motor-1-number').value = '0';
  updateLiveSend();
  await sendCommand(true);
  showToast('Zero-speed command sent and live transmission disabled', 'warning');
}

function renderGenericBuilder() {
  const select = $('#schema-select');
  select.innerHTML = '';
  for (const schema of getOutboundSchemas()) {
    const option = document.createElement('option');
    option.value = String(schema.id);
    option.textContent = `${schema.name} (type ${schema.id})`;
    select.append(option);
  }
  const rawOption = document.createElement('option');
  rawOption.value = 'raw-custom';
  rawOption.textContent = 'Raw payload';
  select.append(rawOption);
  renderSchemaFields();
}

function renderSchemaFields() {
  const container = $('#schema-fields');
  container.innerHTML = '';
  const selection = $('#schema-select').value;

  if (selection === 'raw-custom') {
    container.innerHTML = `
      <label class="field">
        <span>Packet type</span>
        <input id="raw-type" type="number" min="0" max="255" value="0">
      </label>
      <label class="field field-span-2">
        <span>Payload bytes (hex)</span>
        <textarea id="raw-payload" rows="4" placeholder="01 02 ff 10"></textarea>
      </label>
    `;
    return;
  }

  const schema = getSchemaById(Number(selection));
  for (const field of schema.fields ?? []) {
    if (field.hidden) continue;
    if (field.type === 'bitfield8') {
      const group = document.createElement('fieldset');
      group.className = 'field bitfield-group';
      group.dataset.fieldKey = field.key;
      group.innerHTML = `<legend>${escapeHtml(field.label)}</legend>`;
      for (const bit of field.bits ?? []) {
        const label = document.createElement('label');
        label.className = 'check-row';
        label.innerHTML = `<input type="checkbox" data-bit-key="${escapeHtml(bit.key)}" ${bit.default ? 'checked' : ''}><span>${escapeHtml(bit.label)} (bit ${bit.bit})</span>`;
        group.append(label);
      }
      container.append(group);
      continue;
    }

    const label = document.createElement('label');
    label.className = 'field';
    label.dataset.fieldKey = field.key;
    label.dataset.fieldType = field.type;
    const inputType = field.type === 'string' || field.type === 'bytes' ? 'text' : 'number';
    const value = field.default ?? 0;
    label.innerHTML = `
      <span>${escapeHtml(field.label)}</span>
      <input type="${inputType}" value="${escapeHtml(value)}"
        ${field.min !== undefined ? `min="${field.min}"` : ''}
        ${field.max !== undefined ? `max="${field.max}"` : ''}
        ${field.step !== undefined ? `step="${field.step}"` : ''}>
    `;
    container.append(label);
  }
}

function genericBuilderValues(schema) {
  const values = {};
  for (const field of schema.fields ?? []) {
    if (field.hidden) {
      values[field.key] = field.default ?? 0;
      continue;
    }
    if (field.type === 'bitfield8') {
      const group = $(`[data-field-key="${field.key}"]`, $('#schema-fields'));
      values[field.key] = {};
      for (const bit of field.bits ?? []) {
        values[field.key][bit.key] = $(`[data-bit-key="${bit.key}"]`, group).checked;
      }
    } else {
      const wrapper = $(`[data-field-key="${field.key}"]`, $('#schema-fields'));
      const input = $('input, textarea', wrapper);
      values[field.key] = field.type === 'string' || field.type === 'bytes' ? input.value : Number(input.value);
    }
  }
  return values;
}

async function sendGenericPacket() {
  try {
    if (!state.connected && !state.demoRunning) throw new Error('Connect the server serial port or start demo mode first');
    const selection = $('#schema-select').value;
    let type;
    let payload;
    let decoded;
    let label;

    if (selection === 'raw-custom') {
      type = Number($('#raw-type').value);
      payload = hexToBytes($('#raw-payload').value);
      decoded = { raw: bytesToHex(payload) };
      label = 'Raw payload';
    } else {
      const schema = getSchemaById(Number(selection));
      decoded = genericBuilderValues(schema);
      payload = encodePayload(schema, decoded);
      type = schema.id;
      label = schema.name;
    }

    await sendFrame(type, payload, decoded, label);
    $('#builder-preview').textContent = bytesToHex(payload) || '(empty payload)';
    showToast(`${label} packet sent`, 'success');
  } catch (error) {
    showToast(error.message, 'error');
  }
}

function generateDemoTelemetry() {
  const t = performance.now() / 1000;
  const values = {
    loopTimeAvg: Math.round(920 + Math.sin(t * 1.7) * 35),
    loopTimeMax: Math.round(1320 + Math.sin(t * 0.8) * 95),
    runTime: Math.floor(t) & 0xffff,
    rssi: Math.round(72 + Math.sin(t * 0.4) * 7),
    currentMode: Math.floor(t / 8) % 4,
    gimbalPitch: Math.round(Math.sin(t * 0.7) * 1200),
    gimbalYaw: Math.round(Math.cos(t * 0.6) * 1600),
    topServoSet: Math.round(Math.sin(t * 0.7) * 900),
    bottomServoSet: Math.round(Math.cos(t * 0.6) * 900),
    motor1Set: Math.round(80 + Math.sin(t * 0.5) * 15),
    motor2Set: Math.round(82 + Math.cos(t * 0.5) * 15),
    voltage: 0,
    qR: 10000,
    qI: Math.round(Math.sin(t * 0.3) * 1500),
    qJ: Math.round(Math.cos(t * 0.3) * 1500),
    qK: 0,
    accelX: Math.round(Math.sin(t) * 120),
    accelY: Math.round(Math.cos(t * 0.9) * 110),
    accelZ: 980,
    velX: Math.round(Math.sin(t * 0.4) * 30),
    velY: Math.round(Math.cos(t * 0.4) * 30),
    velZ: 0,
    posX: Math.round(Math.sin(t * 0.1) * 100),
    posY: Math.round(Math.cos(t * 0.1) * 100),
    posZ: 15,
    latitude: 47.1164,
    longitude: -88.5385,
  };
  const payload = encodePayload(telemetrySchema, values);
  handlePacket({
    packetNumber: state.rxPackets & 0xffff,
    type: USB_MESSAGE_TYPES.TELEMETRY,
    payloadLength: payload.length,
    payload,
    raw: buildPacket(state.rxPackets & 0xffff, USB_MESSAGE_TYPES.TELEMETRY, payload),
    receivedAt: performance.now(),
  });
}

function toggleDemo() {
  if (state.connected) {
    showToast('Disconnect the server serial port before starting demo mode', 'warning');
    return;
  }
  state.demoRunning = !state.demoRunning;
  window.clearInterval(state.demoTimer);
  state.demoTimer = null;

  if (state.demoRunning) {
    state.demoTimer = window.setInterval(generateDemoTelemetry, 100);
    $('#demo-button').textContent = 'Stop Demo';
    setConnectionStatus(false, 'Demo');
    generateDemoTelemetry();
    appendTerminal('Demo telemetry started', 'system');
  } else {
    $('#demo-button').textContent = 'Demo Data';
    setConnectionStatus(false, 'Disconnected');
    appendTerminal('Demo telemetry stopped', 'system');
  }
}

function exportPacketLog() {
  const data = state.packetRows.map((row) => ({
    timestamp: row.timestamp.toISOString(),
    direction: row.direction,
    packetNumber: row.packetNumber,
    type: row.type,
    effectiveType: row.effectiveType,
    typeName: row.typeName,
    length: row.length,
    payloadHex: bytesToHex(row.payload),
    decoded: row.decoded,
    note: row.note,
  }));
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `aere-usb-packets-${new Date().toISOString().replaceAll(':', '-')}.json`;
  anchor.click();
  URL.revokeObjectURL(url);
}

function bindTabs() {
  $$('.tab-button').forEach((button) => {
    button.addEventListener('click', () => {
      $$('.tab-button').forEach((item) => item.classList.toggle('active', item === button));
      $$('.tab-panel').forEach((panel) => panel.classList.toggle('active', panel.id === `tab-${button.dataset.tab}`));
      if (button.dataset.tab === 'dashboard') {
        renderCharts();
        if (telemetryMap) window.setTimeout(() => telemetryMap.invalidateSize({ pan: false }), 0);
      }
    });
  });
}

function bindEvents() {
  $('#connect-button').addEventListener('click', () => {
    try {
      if (state.connected) {
        link.disconnect();
      } else {
        if (state.demoRunning) toggleDemo();
        const port = $('#serial-port').value;
        link.connect(port, Number($('#baud-rate').value));
        setText('metric-connection', 'Connecting...');
      }
    } catch (error) {
      showToast(error.message, 'error');
      appendTerminal(error.message, 'system');
    }
  });
  $('#refresh-ports').addEventListener('click', () => {
    try {
      link.listPorts();
    } catch (error) {
      showToast(error.message, 'error');
    }
  });
  $('#serial-port').addEventListener('change', () => setConnectionStatus(state.connected));
  $('#demo-button').addEventListener('click', toggleDemo);
  $('#send-command').addEventListener('click', () => sendCommand(false));
  $('#emergency-stop').addEventListener('click', emergencyStop);
  $('#live-send').addEventListener('change', updateLiveSend);
  $('#live-rate').addEventListener('change', updateLiveSend);
  $('#schema-select').addEventListener('change', renderSchemaFields);
  $('#send-generic').addEventListener('click', sendGenericPacket);
  $('#packet-filter').addEventListener('change', renderPacketRows);
  $('#clear-packets').addEventListener('click', () => { state.packetRows = []; renderPacketRows(); });
  $('#export-packets').addEventListener('click', exportPacketLog);
  $('#clear-terminal').addEventListener('click', () => { $('#terminal-output').innerHTML = ''; });
  $('#packet-dialog-close').addEventListener('click', () => $('#packet-dialog').close());
  $('#map-recenter').addEventListener('click', () => {
    if (telemetryMap && lastMapPosition) telemetryMap.setView(lastMapPosition, MAP_ZOOM, { animate: false });
  });
  $('#map-follow').addEventListener('change', (event) => {
    if (event.target.checked && telemetryMap && lastMapPosition) {
      telemetryMap.setView(lastMapPosition, MAP_ZOOM, { animate: false });
    }
  });
  $('#map-clear-trail').addEventListener('click', () => {
    mapTrailCoordinates = lastMapPosition ? [lastMapPosition] : [];
    if (mapTrailLayer) mapTrailLayer.setLatLngs(mapTrailCoordinates);
  });
  window.addEventListener('resize', () => {
    renderCharts();
    if (telemetryMap) telemetryMap.invalidateSize({ pan: false });
  });

  syncRangePair('gimbal-x', 'gimbal-x-number');
  syncRangePair('gimbal-y', 'gimbal-y-number');
  syncRangePair('motor-0', 'motor-0-number');
  syncRangePair('motor-1', 'motor-1-number');
}

link.addEventListener('bridge', (event) => {
  const wasConnected = state.bridgeConnected;
  setBridgeStatus(event.detail.connected);
  if (event.detail.connected && !wasConnected) {
    appendTerminal('Connected to the server-side serial bridge', 'system');
  } else if (!event.detail.connected && wasConnected) {
    appendTerminal('Lost connection to the server-side serial bridge', 'system');
  }
});
link.addEventListener('ports', (event) => renderSerialPorts(event.detail.ports));
link.addEventListener('status', (event) => {
  const wasConnected = state.connected;
  state.currentPort = event.detail.port;
  setConnectionStatus(event.detail.connected);
  if (event.detail.connected && !wasConnected) {
    appendTerminal(`Server opened ${event.detail.port} at ${event.detail.baudRate} baud`, 'system');
  } else if (!event.detail.connected && wasConnected) {
    appendTerminal('Server serial port disconnected', 'system');
  }
});
link.addEventListener('packet', (event) => handlePacket(event.detail));
link.addEventListener('parseerror', (event) => {
  state.badFrames += event.detail.count;
  updatePacketRate();
  appendTerminal(`Parser discarded ${event.detail.count} byte(s) while attempting to resynchronize`, 'system');
});
link.addEventListener('error', (event) => {
  showToast(event.detail.message || String(event.detail), 'error');
  appendTerminal(event.detail.message || String(event.detail), 'system');
});

function initialize() {
  bindTabs();
  bindEvents();
  renderGenericBuilder();
  initializeMap();
  setConnectionStatus(false);
  updatePacketRate();
  renderCharts();

  window.setInterval(updatePacketRate, 250);
  appendTerminal('Dashboard ready. Connecting to the server-side serial bridge...', 'system');
  appendTerminal(`Loaded ${PACKET_SCHEMAS.length} packet schemas.`, 'system');
  link.start();
}

initialize();
