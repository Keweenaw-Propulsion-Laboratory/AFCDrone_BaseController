export const SYNC_BYTES = Object.freeze([0xa5, 0x5a]);
export const PROTOCOL_VERSION = 0x01;

export const SYNC_SIZE = 2;
export const VERSION_SIZE = 1;
export const PACKET_HEADER_SIZE = 4; // packetNum LE16 + type + length
export const CRC_SIZE = 2;
export const FRAME_OVERHEAD = SYNC_SIZE + VERSION_SIZE + PACKET_HEADER_SIZE + CRC_SIZE;
export const FRAME_PREFIX_SIZE = FRAME_OVERHEAD - CRC_SIZE;
export const MIN_FRAME_SIZE = FRAME_OVERHEAD;

export const VERSION_OFFSET = 2;
export const PACKET_NUMBER_OFFSET = 3;
export const TYPE_OFFSET = 5;
export const LENGTH_OFFSET = 6;
export const PAYLOAD_OFFSET = 7;
export const CRC_DATA_OFFSET = PACKET_NUMBER_OFFSET;
export const MAX_PAYLOAD_SIZE = 60;

export const COMMAND_PAYLOAD_SIZE = 8;
export const TELEMETRY_PAYLOAD_SIZE = 54;
export const COMMAND_FRAME_SIZE = FRAME_OVERHEAD + COMMAND_PAYLOAD_SIZE;
export const TELEMETRY_FRAME_SIZE = FRAME_OVERHEAD + TELEMETRY_PAYLOAD_SIZE;

export const CRC16_CONFIG = Object.freeze({
  name: 'CRC-16/CCITT-FALSE',
  polynomial: 0x1021,
  initialValue: 0xffff,
  xorOut: 0x0000,
  reflected: false,
});

export const USB_MESSAGE_TYPES = Object.freeze({
  RAW: 0,
  DEBUG_TEXT: 1,
  RADIO_PACKET: 2,
  TELEMETRY: 3,
  COMMAND: 4,
});

export const USB_MESSAGE_TYPE_NAMES = Object.freeze({
  [USB_MESSAGE_TYPES.RAW]: 'RAW',
  [USB_MESSAGE_TYPES.DEBUG_TEXT]: 'DEBUG_TEXT',
  [USB_MESSAGE_TYPES.RADIO_PACKET]: 'RADIO_PACKET',
  [USB_MESSAGE_TYPES.TELEMETRY]: 'TELEMETRY',
  [USB_MESSAGE_TYPES.COMMAND]: 'COMMAND',
});

const numericTypes = {
  uint8: { size: 1, read: (v, o) => v.getUint8(o), write: (v, o, x) => v.setUint8(o, x) },
  int8: { size: 1, read: (v, o) => v.getInt8(o), write: (v, o, x) => v.setInt8(o, x) },
  uint16: { size: 2, read: (v, o) => v.getUint16(o, true), write: (v, o, x) => v.setUint16(o, x, true) },
  int16: { size: 2, read: (v, o) => v.getInt16(o, true), write: (v, o, x) => v.setInt16(o, x, true) },
  uint32: { size: 4, read: (v, o) => v.getUint32(o, true), write: (v, o, x) => v.setUint32(o, x, true) },
  int32: { size: 4, read: (v, o) => v.getInt32(o, true), write: (v, o, x) => v.setInt32(o, x, true) },
  float32: { size: 4, read: (v, o) => v.getFloat32(o, true), write: (v, o, x) => v.setFloat32(o, x, true) },
  float64: { size: 8, read: (v, o) => v.getFloat64(o, true), write: (v, o, x) => v.setFloat64(o, x, true) },
};

const rawDecoder = (payload) => ({ raw: payload.slice(), hex: bytesToHex(payload) });

export const PACKET_SCHEMAS = [
  {
    id: USB_MESSAGE_TYPES.RAW,
    name: 'Raw',
    direction: 'in',
    variableLength: true,
    minLength: 0,
    maxLength: MAX_PAYLOAD_SIZE,
    decoder: rawDecoder,
  },
  {
    id: USB_MESSAGE_TYPES.DEBUG_TEXT,
    name: 'Debug Text',
    direction: 'in',
    variableLength: true,
    minLength: 0,
    maxLength: MAX_PAYLOAD_SIZE,
    decoder: (payload) => ({ text: new TextDecoder().decode(payload) }),
  },
  {
    id: USB_MESSAGE_TYPES.RADIO_PACKET,
    name: 'Radio Packet',
    direction: 'in',
    variableLength: true,
    minLength: 0,
    maxLength: MAX_PAYLOAD_SIZE,
    decoder: rawDecoder,
  },
  {
    id: USB_MESSAGE_TYPES.TELEMETRY,
    name: 'Telemetry',
    direction: 'in',
    exactLength: TELEMETRY_PAYLOAD_SIZE,
    fields: [
      { key: 'loopTimeAvg', label: 'Average loop time', type: 'uint16', unit: 'us', group: 'Timing' },
      { key: 'loopTimeMax', label: 'Maximum loop time', type: 'uint16', unit: 'us', group: 'Timing' },
      { key: 'runTime', label: 'Runtime', type: 'uint16', unit: 's', group: 'Timing' },
      { key: 'rssi', label: 'RSSI', type: 'uint8', unit: '', group: 'Radio' },
      { key: 'currentMode', label: 'Current mode', type: 'uint8', unit: '', group: 'Status' },

      { key: 'gimbalPitch', label: 'Gimbal pitch', type: 'int16', unit: '', group: 'Gimbal' },
      { key: 'gimbalYaw', label: 'Gimbal yaw', type: 'int16', unit: '', group: 'Gimbal' },
      { key: 'topServoSet', label: 'Top servo setpoint', type: 'int16', unit: '', group: 'Gimbal' },
      { key: 'bottomServoSet', label: 'Bottom servo setpoint', type: 'int16', unit: '', group: 'Gimbal' },

      { key: 'motor1Set', label: 'Motor 1 setpoint', type: 'uint8', unit: '', group: 'Power' },
      { key: 'motor2Set', label: 'Motor 2 setpoint', type: 'uint8', unit: '', group: 'Power' },
      { key: 'voltage', label: 'Voltage', type: 'uint16', unit: '', group: 'Power' },

      { key: 'qR', label: 'Quaternion R', type: 'int16', unit: '', group: 'Quaternion' },
      { key: 'qI', label: 'Quaternion I', type: 'int16', unit: '', group: 'Quaternion' },
      { key: 'qJ', label: 'Quaternion J', type: 'int16', unit: '', group: 'Quaternion' },
      { key: 'qK', label: 'Quaternion K', type: 'int16', unit: '', group: 'Quaternion' },

      { key: 'accelX', label: 'Acceleration X', type: 'int16', unit: '', group: 'Acceleration' },
      { key: 'accelY', label: 'Acceleration Y', type: 'int16', unit: '', group: 'Acceleration' },
      { key: 'accelZ', label: 'Acceleration Z', type: 'int16', unit: '', group: 'Acceleration' },

      { key: 'velX', label: 'Velocity X', type: 'int16', unit: '', group: 'Velocity' },
      { key: 'velY', label: 'Velocity Y', type: 'int16', unit: '', group: 'Velocity' },
      { key: 'velZ', label: 'Velocity Z', type: 'int16', unit: '', group: 'Velocity' },

      { key: 'posX', label: 'Position X', type: 'int16', unit: '', group: 'Position' },
      { key: 'posY', label: 'Position Y', type: 'int16', unit: '', group: 'Position' },
      { key: 'posZ', label: 'Position Z', type: 'int16', unit: '', group: 'Position' },

      { key: 'latitude', label: 'Latitude', type: 'float32', unit: 'deg', group: 'GPS', precision: 7 },
      { key: 'longitude', label: 'Longitude', type: 'float32', unit: 'deg', group: 'GPS', precision: 7 },
    ],
  },
  {
    id: USB_MESSAGE_TYPES.COMMAND,
    name: 'Command',
    direction: 'both',
    exactLength: COMMAND_PAYLOAD_SIZE,
    fields: [
      {
        key: 'flags',
        label: 'Flags',
        type: 'bitfield8',
        group: 'Command',
        reservedMask: 0xfc,
        bits: [
          { key: 'targSlot', label: 'Target slot', bit: 0, default: false },
          { key: 'activeSlot', label: 'Active slot', bit: 1, default: false },
        ],
      },
      { key: 'gimbalX', label: 'Gimbal X', type: 'int16', min: -32768, max: 32767, step: 1, default: 0, group: 'Command' },
      { key: 'gimbalY', label: 'Gimbal Y', type: 'int16', min: -32768, max: 32767, step: 1, default: 0, group: 'Command' },
      { key: 'motor0Speed', label: 'Motor 0 speed', type: 'uint8', min: 0, max: 255, step: 1, default: 0, group: 'Command' },
      { key: 'motor1Speed', label: 'Motor 1 speed', type: 'uint8', min: 0, max: 255, step: 1, default: 0, group: 'Command' },
      { key: 'unused', label: 'Unused', type: 'uint8', default: 0, hidden: true, group: 'Command' },
    ],
  },
];

export function getSchemaById(id) {
  return PACKET_SCHEMAS.find((schema) => schema.id === id) ?? null;
}

export function getOutboundSchemas() {
  return PACKET_SCHEMAS.filter((schema) => schema.direction === 'out' || schema.direction === 'both');
}

export function fieldSize(field) {
  if (field.type === 'bitfield8') return 1;
  if (field.type === 'bytes' || field.type === 'string') return field.length ?? 0;
  const type = numericTypes[field.type];
  if (!type) throw new Error(`Unsupported field type: ${field.type}`);
  return type.size;
}

export function schemaPayloadSize(schema) {
  if (schema.exactLength !== undefined) return schema.exactLength;
  if (schema.variableLength) return null;
  return (schema.fields ?? []).reduce((total, field) => total + fieldSize(field), 0);
}

export function validatePayloadLength(schema, payloadLength) {
  if (!Number.isInteger(payloadLength) || payloadLength < 0 || payloadLength > MAX_PAYLOAD_SIZE) {
    throw new Error(`Payload length must be between 0 and ${MAX_PAYLOAD_SIZE}, received ${payloadLength}`);
  }
  if (!schema) return;
  if (schema.exactLength !== undefined && payloadLength !== schema.exactLength) {
    throw new Error(`${schema.name} payload must be exactly ${schema.exactLength} bytes, received ${payloadLength}`);
  }
  if (schema.minLength !== undefined && payloadLength < schema.minLength) {
    throw new Error(`${schema.name} payload must be at least ${schema.minLength} bytes, received ${payloadLength}`);
  }
  if (schema.maxLength !== undefined && payloadLength > schema.maxLength) {
    throw new Error(`${schema.name} payload must be at most ${schema.maxLength} bytes, received ${payloadLength}`);
  }
}

export function decodePayload(schema, payload) {
  if (!(payload instanceof Uint8Array)) throw new TypeError('Payload must be a Uint8Array');
  if (!schema) return rawDecoder(payload);
  validatePayloadLength(schema, payload.byteLength);
  if (schema.decoder) return schema.decoder(payload);

  const view = new DataView(payload.buffer, payload.byteOffset, payload.byteLength);
  const result = {};
  let offset = 0;

  for (const field of schema.fields ?? []) {
    if (field.type === 'bitfield8') {
      const raw = view.getUint8(offset);
      const value = { _raw: raw };
      for (const bit of field.bits ?? []) value[bit.key] = Boolean(raw & (1 << bit.bit));
      if (field.reservedMask !== undefined) value._reserved = raw & field.reservedMask;
      result[field.key] = value;
      offset += 1;
      continue;
    }

    if (field.type === 'bytes') {
      result[field.key] = payload.slice(offset, offset + field.length);
      offset += field.length;
      continue;
    }

    if (field.type === 'string') {
      const bytes = payload.slice(offset, offset + field.length);
      result[field.key] = new TextDecoder().decode(bytes).replace(/\0+$/, '');
      offset += field.length;
      continue;
    }

    const type = numericTypes[field.type];
    result[field.key] = type.read(view, offset);
    offset += type.size;
  }

  return result;
}

export function encodePayload(schema, values = {}) {
  if (!schema) throw new Error('Cannot encode an unknown schema');
  if (schema.encoder) return schema.encoder(values);

  const size = schemaPayloadSize(schema);
  if (size === null) throw new Error(`${schema.name} has a variable-length payload and needs a custom encoder`);
  if (size > MAX_PAYLOAD_SIZE) throw new Error(`Payload is ${size} bytes; maximum is ${MAX_PAYLOAD_SIZE}`);

  const payload = new Uint8Array(size);
  const view = new DataView(payload.buffer);
  let offset = 0;

  for (const field of schema.fields ?? []) {
    const value = values[field.key] ?? field.default ?? 0;

    if (field.type === 'bitfield8') {
      let raw = 0;
      const bitValues = typeof value === 'object' && value !== null ? value : {};
      for (const bit of field.bits ?? []) {
        const enabled = bitValues[bit.key] ?? bit.default ?? false;
        if (enabled) raw |= 1 << bit.bit;
      }
      if (field.reservedMask !== undefined) raw &= ~field.reservedMask;
      view.setUint8(offset, raw);
      offset += 1;
      continue;
    }

    if (field.type === 'bytes') {
      const source = value instanceof Uint8Array ? value : hexToBytes(String(value));
      payload.set(source.slice(0, field.length), offset);
      offset += field.length;
      continue;
    }

    if (field.type === 'string') {
      const encoded = new TextEncoder().encode(String(value));
      payload.set(encoded.slice(0, field.length), offset);
      offset += field.length;
      continue;
    }

    const type = numericTypes[field.type];
    type.write(view, offset, Number(value));
    offset += type.size;
  }

  validatePayloadLength(schema, payload.byteLength);
  return payload;
}

export function crc16CcittFalse(bytes) {
  let crc = CRC16_CONFIG.initialValue;

  for (const byte of bytes) {
    crc ^= byte << 8;
    for (let bit = 0; bit < 8; bit += 1) {
      crc = (crc & 0x8000) !== 0
        ? ((crc << 1) ^ CRC16_CONFIG.polynomial) & 0xffff
        : (crc << 1) & 0xffff;
    }
  }

  return (crc ^ CRC16_CONFIG.xorOut) & 0xffff;
}

export function buildPacket(packetNumber, type, payload, version = PROTOCOL_VERSION) {
  if (!(payload instanceof Uint8Array)) throw new TypeError('Payload must be a Uint8Array');
  if (payload.byteLength > MAX_PAYLOAD_SIZE) throw new Error(`Payload exceeds ${MAX_PAYLOAD_SIZE} bytes`);
  if (!Number.isInteger(packetNumber)) throw new TypeError('Packet number must be an integer');
  if (!Number.isInteger(type) || type < 0 || type > 0xff) throw new TypeError('Packet type must be a uint8');

  const frame = new Uint8Array(FRAME_OVERHEAD + payload.byteLength);
  const view = new DataView(frame.buffer);
  frame[0] = SYNC_BYTES[0];
  frame[1] = SYNC_BYTES[1];
  view.setUint8(VERSION_OFFSET, version & 0xff);
  view.setUint16(PACKET_NUMBER_OFFSET, packetNumber & 0xffff, true);
  view.setUint8(TYPE_OFFSET, type & 0xff);
  view.setUint8(LENGTH_OFFSET, payload.byteLength);
  frame.set(payload, PAYLOAD_OFFSET);

  const crcOffset = PAYLOAD_OFFSET + payload.byteLength;
  const crc = crc16CcittFalse(frame.subarray(CRC_DATA_OFFSET, crcOffset));
  view.setUint16(crcOffset, crc, true);
  return frame;
}

export function bytesToHex(bytes) {
  return Array.from(bytes, (value) => value.toString(16).padStart(2, '0')).join(' ');
}

export function hexToBytes(text) {
  const normalized = text.replace(/0x/gi, '').replace(/[^0-9a-f]/gi, '');
  if (normalized.length % 2 !== 0) throw new Error('Hex data must contain complete bytes');
  const result = new Uint8Array(normalized.length / 2);
  for (let i = 0; i < normalized.length; i += 2) result[i / 2] = Number.parseInt(normalized.slice(i, i + 2), 16);
  return result;
}

export function formatFieldValue(field, value) {
  if (value === undefined || value === null) return '--';
  if (field.type === 'bitfield8') {
    const enabled = (field.bits ?? []).filter((bit) => value[bit.key]).map((bit) => bit.label);
    if (value._reserved) enabled.push(`Reserved bits: 0x${value._reserved.toString(16).padStart(2, '0')}`);
    return enabled.join(', ') || 'None';
  }
  if (typeof value === 'number' && Number.isFinite(value) && Number.isInteger(field.precision)) {
    return value.toFixed(field.precision);
  }
  return String(value);
}
